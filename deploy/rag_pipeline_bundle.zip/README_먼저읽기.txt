댐 운영 KG + Qwen 파이프라인 묶음 (브랜치 claude/ecstatic-edison-92f1f8 기준)

1) 이 폴더(dam_pilot_data가 보이는 위치)를 서버의 ~/rag-qwen/ 아래에 압축 해제
   unzip rag_pipeline_bundle.zip
2) Neo4j 5.26 Community(Java 21 필요)를 준비하고 NEO4J_HOME 지정
   export NEO4J_HOME=/path/to/neo4j-community-5.26.0
   (conf/neo4j.conf 에서 dbms.security.auth_enabled=false 는 시험용. 접속 주소는 기본값(localhost)을 유지)
   bash dam_pilot_data/scripts/neo4j_up.sh      # 마지막 줄: nodes: 273, rels: 457
3) Qwen 서버 주소와 모델 이름 지정
   export LLM_BASE_URL=http://localhost:8000/v1
   export LLM_MODEL=<서버에 띄운 모델 이름>
4) 먼저 LLM 없이 배관만 점검 (결과는 성과가 아님)
   python3 dam_pilot_data/scripts/step11_pipeline.py --mock --no-answer --questions-file dam_pilot_data/05_retrieval/examples_requests.json
5) 질문 하나로 실제 실행
   python3 dam_pilot_data/scripts/step11_pipeline.py --question "2020년 8월에 충주댐에서 어떤 방류 조작이 있었어?"
6) 질문 19개 실행 후 의도 채점
   python3 dam_pilot_data/scripts/step11_pipeline.py --questions-file dam_pilot_data/05_retrieval/questions_example.json
   python3 dam_pilot_data/scripts/step12_score_intents.py dam_pilot_data/05_retrieval/runs/<방금 생긴 폴더> dam_pilot_data/05_retrieval/questions_example.json
자세한 설명: dam_pilot_data/05_retrieval/RUN_ON_SERVER.md
